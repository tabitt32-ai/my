import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router';
import { Search, ShoppingBag, User, Menu, X } from 'lucide-react';
import { useCartStore } from '@/store/cartStore';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const location = useLocation();
  const totalItems = useCartStore((s) => s.getTotalItems());

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 100);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    setSearchOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { name: 'الرئيسية', path: '/' },
    { name: 'التشكيلة', path: '/products' },
    { name: 'من نحن', path: '/about' },
    { name: 'تواصل معنا', path: '/contact' },
  ];

  return (
    <>
      <nav
        className={`fixed top-0 right-0 left-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-white/95 backdrop-blur-md shadow-sm'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-[1280px] mx-auto px-6 lg:px-20">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 z-10">
              <span className={`font-display text-2xl font-bold ${scrolled ? 'text-brand-gold' : 'text-brand-gold'}`}>
                ليلى
              </span>
              <span className={`font-body text-xs hidden sm:block ${scrolled ? 'text-text-dark' : 'text-text-light'}`}>
                أزياء نسائية
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`font-body text-sm font-medium relative transition-colors duration-300 hover:text-brand-gold ${
                    location.pathname === link.path
                      ? 'text-brand-gold'
                      : scrolled
                      ? 'text-text-dark'
                      : 'text-text-light'
                  }`}
                >
                  {link.name}
                  {location.pathname === link.path && (
                    <span className="absolute -bottom-1 right-0 left-0 h-0.5 bg-brand-gold" />
                  )}
                </Link>
              ))}
            </div>

            {/* Icons */}
            <div className="flex items-center gap-4">
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className={`p-2 transition-all duration-300 hover:text-brand-gold hover:scale-110 ${
                  scrolled ? 'text-text-dark' : 'text-text-light'
                }`}
              >
                <Search size={20} />
              </button>
              <Link
                to="/login"
                className={`p-2 transition-all duration-300 hover:text-brand-gold hover:scale-110 ${
                  scrolled ? 'text-text-dark' : 'text-text-light'
                }`}
              >
                <User size={20} />
              </Link>
              <Link
                to="/cart"
                className={`p-2 transition-all duration-300 hover:text-brand-gold hover:scale-110 relative ${
                  scrolled ? 'text-text-dark' : 'text-text-light'
                }`}
              >
                <ShoppingBag size={20} />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -left-1 bg-brand-gold text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                    {totalItems}
                  </span>
                )}
              </Link>
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className={`lg:hidden p-2 transition-colors ${
                  scrolled ? 'text-text-dark' : 'text-text-light'
                }`}
              >
                {menuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Search Bar */}
        {searchOpen && (
          <div className="absolute top-full right-0 left-0 bg-white shadow-lg border-b border-edge animate-fade-up">
            <div className="max-w-[1280px] mx-auto px-6 lg:px-20 py-4">
              <input
                type="text"
                placeholder="ابحثي عن منتج..."
                autoFocus
                className="w-full font-body text-text-dark placeholder:text-text-muted bg-transparent border-none outline-none text-lg"
              />
            </div>
          </div>
        )}
      </nav>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-40 bg-white">
          <div className="flex flex-col items-center justify-center h-full gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMenuOpen(false)}
                className={`font-display text-2xl transition-colors hover:text-brand-gold ${
                  location.pathname === link.path ? 'text-brand-gold' : 'text-text-dark'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>
        </div>
      )}
    </>
  );
}
