import { Link } from 'react-router';
import { Instagram, Twitter, MessageCircle } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-surface-dark text-text-light">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-20 pt-16 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <h3 className="font-display text-3xl font-bold text-brand-gold mb-4">ليلى</h3>
            <p className="font-body text-sm text-text-light/70 leading-relaxed">
              حيث يلتقي الأصالة بالعصرية. نقدم لكِ تشكيلة فريدة من الأزياء النسائية المصممة بأجود الخامات وأرقى التفاصيل.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display text-lg font-semibold text-brand-gold-light mb-4">روابط سريعة</h4>
            <ul className="space-y-3">
              {[
                { name: 'من نحن', path: '/about' },
                { name: 'سياسة الإرجاع', path: '#' },
                { name: 'الشروط والأحكام', path: '#' },
                { name: 'سياسة الخصوصية', path: '#' },
              ].map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.path}
                    className="font-body text-sm text-text-light/70 hover:text-brand-gold-light transition-colors duration-300"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="font-display text-lg font-semibold text-brand-gold-light mb-4">خدمة العملاء</h4>
            <ul className="space-y-3">
              {[
                { name: 'تواصل معنا', path: '/contact' },
                { name: 'الأسئلة الشائعة', path: '#' },
                { name: 'تتبع الطلب', path: '/track-order' },
                { name: 'دليل المقاسات', path: '#' },
              ].map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.path}
                    className="font-body text-sm text-text-light/70 hover:text-brand-gold-light transition-colors duration-300"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display text-lg font-semibold text-brand-gold-light mb-4">تواصل معنا</h4>
            <div className="space-y-3 font-body text-sm text-text-light/70">
              <p>hello@layla-fashion.sa</p>
              <p>9200xxxxx</p>
              <p>الرياض، المملكة العربية السعودية</p>
            </div>
            <div className="flex items-center gap-4 mt-6">
              <a href="#" className="text-text-light/70 hover:text-brand-gold transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-text-light/70 hover:text-brand-gold transition-colors">
                <MessageCircle size={20} />
              </a>
              <a href="#" className="text-text-light/70 hover:text-brand-gold transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-body text-xs text-text-light/50">
            &copy; 2025 ليلى. جميع الحقوق محفوظة.
          </p>
          <div className="flex items-center gap-3">
            {['Visa', 'Mastercard', 'Mada', 'Apple Pay'].map((method) => (
              <span
                key={method}
                className="font-body text-[10px] text-text-light/50 bg-white/5 px-2 py-1 rounded"
              >
                {method}
              </span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
