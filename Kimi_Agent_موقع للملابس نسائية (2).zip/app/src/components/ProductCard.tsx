import { Link } from 'react-router';
import { Heart } from 'lucide-react';

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  badge?: 'new' | 'sale';
}

export default function ProductCard({ id, name, price, originalPrice, image, badge }: ProductCardProps) {
  return (
    <Link
      to={`/product/${id}`}
      className="group block bg-white rounded-xl shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-400 overflow-hidden"
    >
      <div className="relative overflow-hidden aspect-[3/4]">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
        />
        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
        
        {/* Badge */}
        {badge && (
          <span
            className={`absolute top-3 right-3 font-body text-xs font-medium px-3 py-1 rounded-full ${
              badge === 'new'
                ? 'bg-brand-gold text-white'
                : 'bg-error text-white'
            }`}
          >
            {badge === 'new' ? 'جديد' : 'خصم'}
          </span>
        )}

        {/* Favorite button */}
        <button
          onClick={(e) => e.preventDefault()}
          className="absolute top-3 left-3 w-9 h-9 rounded-full bg-white/90 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-white hover:scale-110"
        >
          <Heart size={16} className="text-text-muted" />
        </button>
      </div>

      <div className="p-4">
        <h3 className="font-display text-base font-medium text-text-dark mb-2 group-hover:text-brand-gold transition-colors">
          {name}
        </h3>
        <div className="flex items-center gap-2">
          <span className="font-body font-bold text-lg text-brand-gold">
            {price.toLocaleString('ar-SA')} ر.س
          </span>
          {originalPrice && (
            <span className="font-body text-sm text-text-muted line-through">
              {originalPrice.toLocaleString('ar-SA')} ر.س
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
