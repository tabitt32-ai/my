import { useState } from 'react';
import { Link } from 'react-router';
import { Eye, EyeOff } from 'lucide-react';

export default function Login() {
  const [isRegister, setIsRegister] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  return (
    <div className="min-h-screen flex">
      {/* Image Side */}
      <div className="hidden lg:block w-1/2 relative">
        <img
          src="/images/login-image.jpg"
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-surface-dark/60 to-transparent" />
        <div className="absolute bottom-10 right-10 left-10">
          <h2 className="font-display text-4xl font-bold text-text-light mb-3">
            ليلى
          </h2>
          <p className="font-body text-text-light/80">
            حيث يلتقي الأصالة بالعصرية
          </p>
        </div>
      </div>

      {/* Form Side */}
      <div className="flex-1 flex items-center justify-center bg-surface-light px-6 lg:px-16 py-10">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <Link to="/" className="inline-block mb-6">
              <span className="font-display text-4xl font-bold text-brand-gold">ليلى</span>
            </Link>
            <h1 className="font-display text-2xl font-semibold text-text-dark mb-2">
              {isRegister ? 'انضمي إلى عائلة ليلى' : 'أهلاً بكِ مجدداً'}
            </h1>
            <p className="font-body text-text-muted text-sm">
              {isRegister
                ? 'سجلي حساباً جديداً واستمتعي بتجربة تسوق مميزة'
                : 'سجلي دخولكِ للوصول إلى حسابكِ ومتابعة طلباتكِ'}
            </p>
          </div>

          <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
            {isRegister && (
              <>
                <div>
                  <label className="font-body text-sm text-text-dark mb-1.5 block">الاسم الكامل</label>
                  <input
                    type="text"
                    name="name"
                    value={form.name}
                    onChange={handleChange}
                    className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/15 transition-all"
                  />
                </div>
                <div>
                  <label className="font-body text-sm text-text-dark mb-1.5 block">رقم الهاتف</label>
                  <input
                    type="tel"
                    name="phone"
                    value={form.phone}
                    onChange={handleChange}
                    className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/15 transition-all"
                    placeholder="05xxxxxxxx"
                  />
                </div>
              </>
            )}

            <div>
              <label className="font-body text-sm text-text-dark mb-1.5 block">البريد الإلكتروني</label>
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/15 transition-all"
              />
            </div>

            <div>
              <label className="font-body text-sm text-text-dark mb-1.5 block">كلمة المرور</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={form.password}
                  onChange={handleChange}
                  className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/15 transition-all pl-12"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-dark"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {isRegister && (
              <div>
                <label className="font-body text-sm text-text-dark mb-1.5 block">تأكيد كلمة المرور</label>
                <input
                  type="password"
                  name="confirmPassword"
                  value={form.confirmPassword}
                  onChange={handleChange}
                  className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/15 transition-all"
                />
              </div>
            )}

            {!isRegister && (
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 font-body text-sm text-text-muted cursor-pointer">
                  <input type="checkbox" className="accent-brand-gold" />
                  تذكرني
                </label>
                <button type="button" className="font-body text-sm text-brand-gold hover:underline">
                  نسيتِ كلمة المرور؟
                </button>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-gradient-gold text-white font-body font-medium py-4 rounded-lg shadow-button hover:shadow-button-hover hover:-translate-y-0.5 transition-all duration-300"
            >
              {isRegister ? 'إنشاء حساب' : 'تسجيل الدخول'}
            </button>
          </form>

          {/* Divider */}
          <div className="flex items-center gap-4 my-6">
            <div className="flex-1 h-px bg-edge" />
            <span className="font-body text-xs text-text-muted">أو</span>
            <div className="flex-1 h-px bg-edge" />
          </div>

          {/* Social Login */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            <button className="flex items-center justify-center gap-2 border border-edge rounded-lg py-3 font-body text-sm text-text-dark hover:border-brand-gold transition-colors">
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              جوجل
            </button>
            <button className="flex items-center justify-center gap-2 border border-edge rounded-lg py-3 font-body text-sm text-text-dark hover:border-brand-gold transition-colors">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="#000">
                <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.22 7.13-.57 1.5-1.31 2.99-2.27 4.08zm-5.85-15.1c.07-2.04 1.76-3.79 3.75-3.94.29 2.32-1.93 4.48-3.75 3.94z"/>
              </svg>
              أبل
            </button>
          </div>

          <p className="text-center font-body text-sm text-text-muted">
            {isRegister ? (
              <>
                لديكِ حساب بالفعل؟{' '}
                <button onClick={() => setIsRegister(false)} className="text-brand-gold hover:underline">
                  سجلي دخولكِ
                </button>
              </>
            ) : (
              <>
                ليس لديكِ حساب؟{' '}
                <button onClick={() => setIsRegister(true)} className="text-brand-gold hover:underline">
                  سجلي الآن
                </button>
              </>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}
