import { useState } from 'react';
import { Link } from 'react-router';
import {
  LayoutDashboard,
  ShoppingBag,
  MapPin,
  UserCircle,
  Lock,
  LogOut,
  Package,
  CheckCircle,
  Truck,
  Star,
  ChevronLeft,
} from 'lucide-react';

const sidebarLinks = [
  { icon: LayoutDashboard, label: 'لوحة التحكم', id: 'dashboard' },
  { icon: ShoppingBag, label: 'طلباتي', id: 'orders' },
  { icon: MapPin, label: 'عناويني', id: 'addresses' },
  { icon: UserCircle, label: 'معلوماتي الشخصية', id: 'profile' },
  { icon: Lock, label: 'تغيير كلمة المرور', id: 'password' },
];

const stats = [
  { title: 'إجمالي الطلبات', value: '١٢', icon: Package },
  { title: 'الطلبات النشطة', value: '٢', icon: Truck },
  { title: 'الطلبات المكتملة', value: '١٠', icon: CheckCircle },
  { title: 'نقاط المكافآت', value: '٥٠٠', icon: Star },
];

const orders = [
  { id: '#12345', date: '١٥ يناير ٢٠٢٥', status: 'قيد الشحن', total: '١٧٩٦ ر.س', statusColor: 'text-brand-gold' },
  { id: '#12344', date: '١٠ يناير ٢٠٢٥', status: 'مكتمل', total: '٨٩٧ ر.س', statusColor: 'text-success' },
  { id: '#12343', date: '٥ يناير ٢٠٢٥', status: 'مكتمل', total: '١٢٩٧ ر.س', statusColor: 'text-success' },
  { id: '#12342', date: '٢٨ ديسمبر ٢٠٢٤', status: 'مكتمل', total: '٥٩٩ ر.س', statusColor: 'text-success' },
  { id: '#12341', date: '٢٠ ديسمبر ٢٠٢٤', status: 'مكتمل', total: '٣٩٩ ر.س', statusColor: 'text-success' },
];

const addresses = [
  { id: 1, name: 'المنزل', address: 'حي العليا، شارع العروبة، برج المملكة', city: 'الرياض', default: true },
  { id: 2, name: 'العمل', address: 'حي الروضة، شارارع التحلية', city: 'جدة', default: false },
];

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div>
            <h2 className="font-display text-2xl font-semibold text-text-dark mb-2">
              مرحباً، نورة
            </h2>
            <p className="font-body text-text-muted mb-8">إليك نظرة عامة على حسابكِ</p>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
              {stats.map((stat, i) => (
                <div key={i} className="bg-white rounded-xl p-6 shadow-card">
                  <div className="w-10 h-10 rounded-lg bg-brand-gold/10 flex items-center justify-center mb-4">
                    <stat.icon size={20} className="text-brand-gold" />
                  </div>
                  <p className="font-body text-2xl font-bold text-text-dark mb-1">{stat.value}</p>
                  <p className="font-body text-sm text-text-muted">{stat.title}</p>
                </div>
              ))}
            </div>

            <h3 className="font-display text-lg font-semibold text-text-dark mb-4">
              آخر الطلبات
            </h3>
            <div className="bg-white rounded-xl shadow-card overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-surface-light">
                    <tr>
                      <th className="font-body text-sm text-text-muted text-right py-3 px-4">رقم الطلب</th>
                      <th className="font-body text-sm text-text-muted text-right py-3 px-4">التاريخ</th>
                      <th className="font-body text-sm text-text-muted text-right py-3 px-4">الحالة</th>
                      <th className="font-body text-sm text-text-muted text-right py-3 px-4">المجموع</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.slice(0, 3).map((order) => (
                      <tr key={order.id} className="border-b border-edge last:border-0">
                        <td className="font-body text-sm text-text-dark py-3 px-4">{order.id}</td>
                        <td className="font-body text-sm text-text-muted py-3 px-4">{order.date}</td>
                        <td className={`font-body text-sm py-3 px-4 ${order.statusColor}`}>{order.status}</td>
                        <td className="font-body text-sm text-brand-gold py-3 px-4 font-medium">{order.total}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      case 'orders':
        return (
          <div>
            <h2 className="font-display text-2xl font-semibold text-text-dark mb-6">طلباتي</h2>
            <div className="bg-white rounded-xl shadow-card overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-surface-light">
                    <tr>
                      <th className="font-body text-sm text-text-muted text-right py-3 px-4">رقم الطلب</th>
                      <th className="font-body text-sm text-text-muted text-right py-3 px-4">التاريخ</th>
                      <th className="font-body text-sm text-text-muted text-right py-3 px-4">الحالة</th>
                      <th className="font-body text-sm text-text-muted text-right py-3 px-4">المجموع</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map((order) => (
                      <tr key={order.id} className="border-b border-edge last:border-0">
                        <td className="font-body text-sm text-text-dark py-4 px-4">{order.id}</td>
                        <td className="font-body text-sm text-text-muted py-4 px-4">{order.date}</td>
                        <td className={`font-body text-sm py-4 px-4 ${order.statusColor}`}>{order.status}</td>
                        <td className="font-body text-sm text-brand-gold py-4 px-4 font-medium">{order.total}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      case 'addresses':
        return (
          <div>
            <h2 className="font-display text-2xl font-semibold text-text-dark mb-6">عناويني</h2>
            <div className="space-y-4">
              {addresses.map((addr) => (
                <div key={addr.id} className="bg-white rounded-xl p-6 shadow-card">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-body font-semibold text-text-dark">{addr.name}</h4>
                        {addr.default && (
                          <span className="font-body text-[10px] bg-brand-gold/10 text-brand-gold px-2 py-0.5 rounded-full">
                            افتراضي
                          </span>
                        )}
                      </div>
                      <p className="font-body text-sm text-text-muted">{addr.address}</p>
                      <p className="font-body text-sm text-text-muted">{addr.city}</p>
                    </div>
                    <button className="text-brand-gold hover:underline font-body text-sm">
                      تعديل
                    </button>
                  </div>
                </div>
              ))}
              <button className="w-full border-2 border-dashed border-edge rounded-xl py-4 font-body text-brand-gold hover:border-brand-gold transition-colors">
                + إضافة عنوان جديد
              </button>
            </div>
          </div>
        );

      case 'profile':
        return (
          <div>
            <h2 className="font-display text-2xl font-semibold text-text-dark mb-6">معلوماتي الشخصية</h2>
            <div className="bg-white rounded-xl p-8 shadow-card">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="font-body text-sm text-text-dark mb-2 block">الاسم الكامل</label>
                  <input type="text" defaultValue="نورة العتيبي" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                </div>
                <div>
                  <label className="font-body text-sm text-text-dark mb-2 block">البريد الإلكتروني</label>
                  <input type="email" defaultValue="nora@example.com" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                </div>
                <div>
                  <label className="font-body text-sm text-text-dark mb-2 block">رقم الهاتف</label>
                  <input type="tel" defaultValue="055xxxxxxx" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                </div>
                <div>
                  <label className="font-body text-sm text-text-dark mb-2 block">تاريخ الميلاد</label>
                  <input type="date" defaultValue="1990-05-15" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                </div>
              </div>
              <button className="mt-6 bg-gradient-gold text-white font-body font-medium px-8 py-3 rounded-lg shadow-button hover:shadow-button-hover transition-all">
                حفظ التغييرات
              </button>
            </div>
          </div>
        );

      case 'password':
        return (
          <div>
            <h2 className="font-display text-2xl font-semibold text-text-dark mb-6">تغيير كلمة المرور</h2>
            <div className="bg-white rounded-xl p-8 shadow-card max-w-lg">
              <div className="space-y-4">
                <div>
                  <label className="font-body text-sm text-text-dark mb-2 block">كلمة المرور الحالية</label>
                  <input type="password" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                </div>
                <div>
                  <label className="font-body text-sm text-text-dark mb-2 block">كلمة المرور الجديدة</label>
                  <input type="password" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                </div>
                <div>
                  <label className="font-body text-sm text-text-dark mb-2 block">تأكيد كلمة المرور الجديدة</label>
                  <input type="password" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                </div>
              </div>
              <button className="mt-6 bg-gradient-gold text-white font-body font-medium px-8 py-3 rounded-lg shadow-button hover:shadow-button-hover transition-all">
                تحديث كلمة المرور
              </button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen pt-20 bg-surface-light">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-20 py-10">
        <div className="flex gap-8">
          {/* Sidebar */}
          <aside className="hidden lg:block w-72 shrink-0">
            <div className="bg-white rounded-xl shadow-card p-6 sticky top-24">
              {/* User Info */}
              <div className="text-center mb-6 pb-6 border-b border-edge">
                <div className="w-16 h-16 rounded-full bg-gradient-gold mx-auto mb-3 flex items-center justify-center">
                  <span className="font-display text-xl font-bold text-white">ن</span>
                </div>
                <h4 className="font-display font-semibold text-text-dark">نورة العتيبي</h4>
                <p className="font-body text-xs text-text-muted">nora@example.com</p>
              </div>

              {/* Links */}
              <nav className="space-y-1">
                {sidebarLinks.map((link) => (
                  <button
                    key={link.id}
                    onClick={() => setActiveTab(link.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg font-body text-sm transition-all ${
                      activeTab === link.id
                        ? 'bg-brand-gold/10 text-brand-gold font-medium'
                        : 'text-text-muted hover:bg-surface-light hover:text-text-dark'
                    }`}
                  >
                    <link.icon size={18} />
                    {link.label}
                    <ChevronLeft size={14} className="mr-auto" />
                  </button>
                ))}
                <Link
                  to="/"
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg font-body text-sm text-error hover:bg-error/5 transition-all mt-4"
                >
                  <LogOut size={18} />
                  تسجيل الخروج
                </Link>
              </nav>
            </div>
          </aside>

          {/* Content */}
          <main className="flex-1 min-w-0">
            {renderContent()}
          </main>
        </div>
      </div>
    </div>
  );
}
