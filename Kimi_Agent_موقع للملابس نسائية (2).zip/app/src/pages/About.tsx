import { useEffect, useRef } from 'react';
import { Sparkles, Lightbulb, Handshake } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const values = [
  {
    icon: Sparkles,
    title: 'الجودة',
    description: 'نختار أجود الخامات ونراقب كل تفصيلة لنقدم لكِ الأفضل دائماً',
  },
  {
    icon: Lightbulb,
    title: 'الإبداع',
    description: 'نستلهم من تراثنا ونبتكر تصاميم تلهم الجميع',
  },
  {
    icon: Handshake,
    title: 'الثقة',
    description: 'نعمل بشفافية ونبني علاقة ثقة مع كل عميلة',
  },
];

const team = [
  { name: 'ليلى العتيبي', role: 'المؤسسة والمصممة الرئيسية' },
  { name: 'نورة القحطاني', role: 'مديرة التصميم' },
  { name: 'سارة الدوسري', role: 'مديرة التسويق' },
  { name: 'فاطمة الشمري', role: 'مديرة العمليات' },
];

export default function About() {
  const sectionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.fade-up').forEach((el) => {
        gsap.fromTo(el, { opacity: 0, y: 40 }, {
          opacity: 1, y: 0, duration: 0.8, ease: 'power3.out',
          scrollTrigger: { trigger: el, start: 'top 85%' },
        });
      });
      gsap.utils.toArray<HTMLElement>('.scale-in').forEach((el) => {
        gsap.fromTo(el, { opacity: 0, scale: 0.95 }, {
          opacity: 1, scale: 1, duration: 1, ease: 'power2.out',
          scrollTrigger: { trigger: el, start: 'top 85%' },
        });
      });
    }, sectionsRef);
    return () => ctx.revert();
  }, []);

  return (
    <div ref={sectionsRef} className="min-h-screen pt-20">
      {/* Hero */}
      <section className="bg-surface-dark py-28 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto text-center">
          <h1 className="fade-up font-display text-5xl lg:text-6xl font-bold text-text-light mb-6">
            قصة ليلى
          </h1>
          <p className="fade-up font-body text-lg lg:text-xl text-brand-gold-light max-w-2xl mx-auto">
            منذ عام ٢٠٢٠، نحكي قصة أناقة تجمع بين تراثنا العريق وروح العصر
          </p>
          <div className="line-grow line-gold mx-auto mt-8" />
        </div>
      </section>

      {/* Our Story */}
      <section className="bg-surface-light py-24 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="fade-up font-display text-4xl font-semibold text-text-dark mb-6">
                نبتكر الأناقة بروح شرقية
              </h2>
              <p className="fade-up font-body text-text-muted leading-relaxed mb-6">
                بدأت قصة ليلى من حلم بسيط... أن نصمم أزياء تعكس هوية المرأة العربية العصرية. منذ انطلاقتنا في عام ٢٠٢٠، نسعى لتقديم تجربة فريدة تجمع بين جودة الخامات الفاخرة وتصاميم تتناغم مع أحدث صيحات الموضة العالمية مع الحفاظ على لمسة تراثية أصيلة. نختار كل قماشة بعناية، ونراقب كل تفصيلة بدقة، لنقدم لكِ قطعة لا تلبسينها فحسب، بل تحتفظين بها ذكرى جميلة.
              </p>
              <div className="fade-up grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8">
                <div>
                  <h4 className="font-display text-lg font-semibold text-brand-gold mb-2">رسالتنا</h4>
                  <p className="font-body text-sm text-text-muted leading-relaxed">
                    تمكين المرأة العربية من التعبير عن ذاتها من خلال أزياء تجمع بين الأصالة والعصرية، بجودة عالمية وتصاميم تلهم.
                  </p>
                </div>
                <div>
                  <h4 className="font-display text-lg font-semibold text-brand-gold mb-2">رؤيتنا</h4>
                  <p className="font-body text-sm text-text-muted leading-relaxed">
                    أن نكون الخيار الأول للمرأة العربية التي تبحث عن الأناقة والتميز في كل مناسبة.
                  </p>
                </div>
              </div>
            </div>
            <div className="scale-in">
              <img
                src="/images/our-story.jpg"
                alt="قصة ليلى"
                className="w-full aspect-[4/3] object-cover rounded-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="bg-white py-24 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto">
          <div className="text-center mb-12">
            <h2 className="fade-up font-display text-4xl font-semibold text-text-dark">
              قيمنا
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((v, i) => (
              <div
                key={i}
                className="fade-up bg-surface-light rounded-xl p-10 text-center"
              >
                <div className="w-14 h-14 rounded-full bg-brand-gold/10 flex items-center justify-center mx-auto mb-6">
                  <v.icon size={28} className="text-brand-gold" />
                </div>
                <h3 className="font-display text-xl font-semibold text-text-dark mb-4">
                  {v.title}
                </h3>
                <p className="font-body text-text-muted leading-relaxed">
                  {v.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="bg-surface-light py-24 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto">
          <div className="text-center mb-12">
            <h2 className="fade-up font-display text-4xl font-semibold text-text-dark">
              فريق ليلى
            </h2>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, i) => (
              <div key={i} className="fade-up text-center">
                <div className="w-28 h-28 lg:w-32 lg:h-32 rounded-full bg-gradient-gold mx-auto mb-4 flex items-center justify-center">
                  <span className="font-display text-2xl font-bold text-white">
                    {member.name.charAt(0)}
                  </span>
                </div>
                <h4 className="font-display text-lg font-semibold text-text-dark mb-1">
                  {member.name}
                </h4>
                <p className="font-body text-sm text-text-muted">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
