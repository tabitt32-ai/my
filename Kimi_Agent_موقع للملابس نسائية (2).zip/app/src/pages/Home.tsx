import { useEffect, useRef } from 'react';
import { Link } from 'react-router';
import { ChevronDown, Truck, Sparkles, RefreshCw, ShieldCheck } from 'lucide-react';
import ProductCard from '@/components/ProductCard';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const products = [
  { id: '1', name: 'فستان سهرة أخضر زمردي', price: 799, originalPrice: 999, image: '/images/product-main.jpg', badge: 'sale' as const },
  { id: '5', name: 'تنورة حريرية بيج', price: 399, image: '/images/category-skirts.jpg', badge: 'new' as const },
  { id: '6', name: 'بلوزة عنبرية', price: 299, originalPrice: 349, image: '/images/category-tops.jpg', badge: 'sale' as const },
  { id: '10', name: 'معطف شتوي جملي', price: 599, image: '/images/category-coats.jpg' },
];

const categories = [
  { name: 'فساتين', image: '/images/category-dresses.jpg' },
  { name: 'تنانير', image: '/images/category-skirts.jpg' },
  { name: 'قمصان وبلوزات', image: '/images/category-tops.jpg' },
  { name: 'معاطف وجاكيتات', image: '/images/category-coats.jpg' },
];

const testimonials = [
  { name: 'نورة العتيبي', text: 'تجربة تسوق لا تُنسى... جودة القماش رائعة والتصميم أروع. الفستان اللي طلبته تجاوز توقعاتي بمراحل. شكراً ليلى على الأناقة الحقيقية.' },
  { name: 'سارة القحطاني', text: 'من أفضل المتاجر اللي تعاملت معها. خدمة العملاء ممتازة والتوصيل سريع. القطع كلها فاخرة وبيّنة جودتها من أول نظرة.' },
  { name: 'فاطمة الدوسري', text: 'أحب التشكيلة الجديدة! التصاميم تجمع بين الأصالة والعصرية بطريقة ساحرة. أنصح كل البنات بتجربة ليلى.' },
];

const features = [
  { icon: Truck, title: 'شحن مجاني', desc: 'مجاناً للطلبات فوق ٣٩٩ ر.س' },
  { icon: Sparkles, title: 'جودة مضمونة', desc: 'أجود الخامات وأدق التفاصيل' },
  { icon: RefreshCw, title: 'إرجاع سهل', desc: '١٤ يوماً لإرجاع المنتج' },
  { icon: ShieldCheck, title: 'دفع آمن', desc: 'تشفير كامل لبيانات الدفع' },
];

export default function Home() {
  const heroRef = useRef<HTMLDivElement>(null);
  const sectionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero animations
      const heroTl = gsap.timeline();
      heroTl.fromTo('.hero-logo', { opacity: 0, scale: 0.9 }, { opacity: 1, scale: 1, duration: 0.8, ease: 'power3.out' })
        .fromTo('.hero-title', { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 1, ease: 'power3.out' }, '-=0.4')
        .fromTo('.hero-subtitle', { opacity: 0, y: 20, filter: 'blur(8px)' }, { opacity: 1, y: 0, filter: 'blur(0px)', duration: 1, ease: 'power3.out' }, '-=0.5')
        .fromTo('.hero-cta', { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' }, '-=0.5')
        .fromTo('.hero-scroll', { opacity: 0 }, { opacity: 1, duration: 0.5 }, '-=0.2');

      // Scroll animations
      gsap.utils.toArray<HTMLElement>('.fade-up').forEach((el) => {
        gsap.fromTo(el, { opacity: 0, y: 40 }, {
          opacity: 1, y: 0, duration: 0.8, ease: 'power3.out',
          scrollTrigger: { trigger: el, start: 'top 85%' },
        });
      });

      gsap.utils.toArray<HTMLElement>('.scale-in').forEach((el) => {
        gsap.fromTo(el, { opacity: 0, scale: 0.95 }, {
          opacity: 1, scale: 1, duration: 1, ease: 'power2.out',
          scrollTrigger: { trigger: el, start: 'top 85%' },
        });
      });

      gsap.utils.toArray<HTMLElement>('.line-grow').forEach((el) => {
        gsap.fromTo(el, { scaleX: 0 }, {
          scaleX: 1, duration: 1.2, ease: 'power3.inOut',
          scrollTrigger: { trigger: el, start: 'top 85%' },
        });
      });
    }, sectionsRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={sectionsRef}>
      {/* Hero */}
      <section ref={heroRef} className="relative h-screen w-full overflow-hidden flex items-center justify-center">
        {/* Video Background */}
        <video
          autoPlay
          muted
          loop
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
          poster="/images/category-dresses.jpg"
        >
          <source src="/videos/hero-video.mp4" type="video/mp4" />
        </video>
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-surface-dark/50 to-surface-dark/70" />

        {/* Content */}
        <div className="relative z-10 text-center px-6 max-w-3xl mx-auto">
          <h2 className="hero-logo font-display text-5xl md:text-6xl font-bold text-brand-gold mb-2 opacity-0">
            ليلى
          </h2>
          <h1 className="hero-title font-display text-5xl md:text-7xl font-bold text-text-light mb-6 opacity-0 leading-tight">
            أناقة لا تُضاهى
          </h1>
          <p className="hero-subtitle font-body text-lg md:text-xl text-brand-gold-light mb-10 opacity-0">
            تشكيلة خريف وشتاء 2025... إطلالة تجمع بين الأصالة والعصرية
          </p>
          <Link
            to="/products"
            className="hero-cta inline-block bg-gradient-gold text-white font-body font-medium text-lg px-12 py-4 rounded-lg shadow-button hover:shadow-button-hover hover:-translate-y-0.5 transition-all duration-300 opacity-0"
          >
            اكتشفي التشكيلة
          </Link>
        </div>

        {/* Scroll indicator */}
        <div className="hero-scroll absolute bottom-8 left-1/2 -translate-x-1/2 opacity-0">
          <ChevronDown size={32} className="text-brand-gold-light animate-bounce" />
        </div>
      </section>

      {/* Featured Categories */}
      <section className="bg-surface-light py-24 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto">
          <div className="text-center mb-16">
            <h2 className="fade-up font-display text-4xl font-semibold text-text-dark mb-4">
              تشكيلاتنا المميزة
            </h2>
            <div className="line-grow line-gold mx-auto origin-center" />
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((cat) => (
              <Link
                key={cat.name}
                to="/products"
                className="scale-in group relative overflow-hidden rounded-2xl aspect-[3/4]"
              >
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <span className="absolute bottom-6 right-6 font-display text-xl lg:text-2xl font-semibold text-text-light">
                  {cat.name}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="bg-white py-24 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto">
          <div className="flex items-center justify-between mb-12">
            <div className="flex items-center gap-3">
              <h2 className="fade-up font-display text-4xl font-semibold text-text-dark">وصل حديثاً</h2>
              <span className="fade-up bg-brand-gold text-white font-body text-xs font-medium px-3 py-1 rounded-full">
                جديد
              </span>
            </div>
            <Link
              to="/products"
              className="fade-up font-body text-sm text-brand-gold hover:text-brand-gold-dark transition-colors border border-brand-gold px-6 py-3 rounded-lg hover:bg-brand-gold/5"
            >
              عرض الكل ←
            </Link>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((product, i) => (
              <div key={product.id} className="fade-up" style={{ animationDelay: `${i * 0.15}s` }}>
                <ProductCard {...product} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Teaser */}
      <section className="bg-gradient-warm py-24 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="scale-in">
              <img
                src="/images/about-teaser.jpg"
                alt="عن ليلى"
                className="w-full aspect-[4/3] object-cover rounded-2xl"
              />
            </div>
            <div>
              <h2 className="fade-up font-display text-4xl font-semibold text-text-dark mb-6">
                حيث تُروى قصص الأناقة
              </h2>
              <p className="fade-up font-body text-text-muted leading-relaxed mb-8">
                ليلى... اسم يرتبط بأرقى معاني الأناقة النسائية. منذ انطلاقتنا، نسعى لتقديم تصاميم فريدة تجمع بين روح الشرق وسحر العصر. كل قطعة نصممها تحمل في طياتها قصة إبداع، وروح حرفية، وشغف بأدق التفاصيل. نؤمن بأن الأناقة ليست مجرد مظهر، بل هي تعبير عن الذات وثقة تنبض من الداخل.
              </p>
              <Link
                to="/about"
                className="fade-up inline-block bg-gradient-gold text-white font-body font-medium px-8 py-4 rounded-lg shadow-button hover:shadow-button-hover hover:-translate-y-0.5 transition-all duration-300"
              >
                تعرفي علينا أكثر
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-surface-dark py-24 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto">
          <div className="text-center mb-16">
            <h2 className="fade-up font-display text-4xl font-semibold text-brand-gold-light mb-4">
              آراء عملائنا
            </h2>
            <div className="line-grow line-gold mx-auto" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <div
                key={i}
                className="fade-up bg-white/5 border border-brand-gold/20 rounded-xl p-8"
              >
                <span className="font-display text-5xl text-brand-gold leading-none">"</span>
                <p className="font-body text-text-light/80 leading-relaxed mb-6 -mt-2">
                  {t.text}
                </p>
                <div className="flex items-center gap-2">
                  <span className="font-body font-semibold text-text-light">{t.name}</span>
                  <div className="flex text-brand-gold text-sm">
                    {'★'.repeat(5)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="bg-surface-light py-16 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto">
          <div className="fade-up grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="font-display text-3xl font-semibold text-text-dark mb-4">
                كوني أول من يعلم
              </h3>
              <p className="font-body text-text-muted">
                اشتركي في نشرتنا البريدية واحصلي على تشكيلات حصرية وعروض خاصة مباشرة إلى بريدكِ.
              </p>
            </div>
            <div className="flex gap-3">
              <input
                type="email"
                placeholder="بريدكِ الإلكتروني"
                className="flex-1 bg-white border border-edge rounded-lg px-4 py-4 font-body text-text-dark placeholder:text-text-muted outline-none focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/15 transition-all"
              />
              <button className="bg-gradient-gold text-white font-body font-medium px-8 py-4 rounded-lg shadow-button hover:shadow-button-hover hover:-translate-y-0.5 transition-all duration-300">
                اشتركي الآن
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Bar */}
      <section className="bg-white border-t border-edge py-12 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((f, i) => (
              <div key={i} className="fade-up flex flex-col items-center text-center gap-3">
                <f.icon size={36} className="text-brand-gold" />
                <h4 className="font-body font-semibold text-text-dark">{f.title}</h4>
                <p className="font-body text-sm text-text-muted">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
