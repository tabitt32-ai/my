import { useState } from 'react';
import { Search, Package, CheckCircle, Truck, Home } from 'lucide-react';

const trackingSteps = [
  { icon: CheckCircle, label: 'تأكيد الطلب', date: '١٥ يناير ٢٠٢٥', done: true },
  { icon: Package, label: 'قيد المعالجة', date: '١٦ يناير ٢٠٢٥', done: true },
  { icon: Truck, label: 'قيد الشحن', date: '١٧ يناير ٢٠٢٥', done: true, active: true },
  { icon: Home, label: 'تم التوصيل', date: 'متوقع ١٨-٢٠ يناير', done: false },
];

const orderItems = [
  { name: 'فستان سهرة أخضر زمردي', qty: 1, price: 799 },
  { name: 'بلوزة عنبرية', qty: 2, price: 598 },
];

export default function OrderTracking() {
  const [orderNumber, setOrderNumber] = useState('');
  const [showResult, setShowResult] = useState(false);

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (orderNumber.trim()) {
      setShowResult(true);
    }
  };

  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-20 py-16">
        <h1 className="font-display text-4xl font-semibold text-text-dark mb-4 text-center">
          تتبع طلبكِ
        </h1>
        <p className="font-body text-text-muted text-center mb-10">
          أدخلي رقم طلبكِ لمعرفة حالته والموعد المتوقع للتوصيل
        </p>

        {/* Tracking Form */}
        <form onSubmit={handleTrack} className="max-w-lg mx-auto mb-16">
          <div className="flex gap-3">
            <input
              type="text"
              value={orderNumber}
              onChange={(e) => setOrderNumber(e.target.value)}
              placeholder="رقم الطلب"
              className="flex-1 border border-edge rounded-lg px-4 py-4 font-body text-lg text-center outline-none focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/15 transition-all tracking-widest"
            />
            <button
              type="submit"
              className="bg-gradient-gold text-white px-8 py-4 rounded-lg shadow-button hover:shadow-button-hover transition-all flex items-center gap-2"
            >
              <Search size={20} />
              <span className="font-body font-medium">تتبع</span>
            </button>
          </div>
        </form>

        {/* Tracking Result */}
        {showResult && (
          <div className="bg-white rounded-xl p-8 shadow-card">
            {/* Order Info */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-10 pb-8 border-b border-edge">
              <div>
                <p className="font-body text-sm text-text-muted mb-1">رقم الطلب</p>
                <p className="font-body font-semibold text-text-dark text-lg">#12345</p>
              </div>
              <div>
                <p className="font-body text-sm text-text-muted mb-1">تاريخ الطلب</p>
                <p className="font-body font-semibold text-text-dark text-lg">١٥ يناير ٢٠٢٥</p>
              </div>
              <div>
                <p className="font-body text-sm text-text-muted mb-1">حالة الطلب</p>
                <p className="font-body font-semibold text-brand-gold text-lg">قيد الشحن</p>
              </div>
              <div>
                <p className="font-body text-sm text-text-muted mb-1">الموعد المتوقع</p>
                <p className="font-body font-semibold text-text-dark text-lg">١٨-٢٠ يناير ٢٠٢٥</p>
              </div>
            </div>

            {/* Progress */}
            <div className="mb-10">
              <div className="flex items-center justify-between relative">
                <div className="absolute top-1/2 right-0 left-0 h-1 bg-edge -translate-y-1/2" />
                <div
                  className="absolute top-1/2 right-0 h-1 bg-brand-gold -translate-y-1/2 transition-all"
                  style={{ width: '66%' }}
                />
                {trackingSteps.map((step, i) => (
                  <div key={i} className="relative z-10 flex flex-col items-center">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                        step.done
                          ? step.active
                            ? 'bg-brand-gold text-white ring-4 ring-brand-gold/20'
                            : 'bg-brand-gold text-white'
                          : 'bg-white border-2 border-edge text-text-muted'
                      }`}
                    >
                      <step.icon size={20} />
                    </div>
                    <p className={`font-body text-xs mt-2 ${step.done ? 'text-text-dark font-medium' : 'text-text-muted'}`}>
                      {step.label}
                    </p>
                    <p className="font-body text-[10px] text-text-muted">{step.date}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Items */}
            <div>
              <h3 className="font-display text-lg font-semibold text-text-dark mb-4">
                محتويات الطلب
              </h3>
              <div className="space-y-3">
                {orderItems.map((item, i) => (
                  <div key={i} className="flex justify-between items-center py-3 border-b border-edge last:border-0">
                    <div>
                      <p className="font-body text-text-dark">{item.name}</p>
                      <p className="font-body text-sm text-text-muted">الكمية: {item.qty}</p>
                    </div>
                    <span className="font-body font-medium text-brand-gold">
                      {item.price.toLocaleString('ar-SA')} ر.س
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
