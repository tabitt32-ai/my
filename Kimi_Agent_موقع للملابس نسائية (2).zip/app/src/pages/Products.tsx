import { useState } from 'react';
import { SlidersHorizontal, X } from 'lucide-react';
import ProductCard from '@/components/ProductCard';

const allProducts = [
  { id: '1', name: 'فستان سهرة أخضر زمردي', price: 799, originalPrice: 999, image: '/images/product-main.jpg', badge: 'sale' as const, category: 'فساتين', color: 'أخضر', sizes: ['S', 'M', 'L'] },
  { id: '2', name: 'فستان عنبرية حريري', price: 699, image: '/images/category-tops.jpg', badge: 'new' as const, category: 'فساتين', color: 'عنبر', sizes: ['S', 'M'] },
  { id: '3', name: 'فستان أسود كلاسيكي', price: 599, originalPrice: 799, image: '/images/category-coats.jpg', badge: 'sale' as const, category: 'فساتين', color: 'أسود', sizes: ['S', 'M', 'L', 'XL'] },
  { id: '4', name: 'فستان أبيض ناعم', price: 499, image: '/images/category-dresses.jpg', category: 'فساتين', color: 'أبيض', sizes: ['M', 'L'] },
  { id: '5', name: 'تنورة حريرية بيج', price: 399, image: '/images/category-skirts.jpg', badge: 'new' as const, category: 'تنانير', color: 'بيج', sizes: ['S', 'M', 'L'] },
  { id: '6', name: 'تنورة سوداء ميدي', price: 299, originalPrice: 349, image: '/images/category-skirts.jpg', badge: 'sale' as const, category: 'تنانير', color: 'أسود', sizes: ['S', 'M', 'L', 'XL'] },
  { id: '7', name: 'بلوزة عنبرية', price: 299, originalPrice: 349, image: '/images/category-tops.jpg', badge: 'sale' as const, category: 'قمصان وبلوزات', color: 'عنبر', sizes: ['S', 'M', 'L'] },
  { id: '8', name: 'قميص أبيض كلاسيكي', price: 249, image: '/images/category-tops.jpg', category: 'قمصان وبلوزات', color: 'أبيض', sizes: ['S', 'M', 'L', 'XL', 'XXL'] },
  { id: '9', name: 'بلوزة خضراء مطرزة', price: 349, originalPrice: 399, image: '/images/category-tops.jpg', badge: 'sale' as const, category: 'قمصان وبلوزات', color: 'أخضر', sizes: ['S', 'M'] },
  { id: '10', name: 'معطف شتوي جملي', price: 599, image: '/images/category-coats.jpg', category: 'معاطف وجاكيتات', color: 'جملي', sizes: ['S', 'M', 'L'] },
  { id: '11', name: 'جاكيت أسود قصير', price: 499, originalPrice: 599, image: '/images/category-coats.jpg', badge: 'sale' as const, category: 'معاطف وجاكيتات', color: 'أسود', sizes: ['S', 'M', 'L'] },
  { id: '12', name: 'وشاح حريري عنبر', price: 199, originalPrice: 249, image: '/images/product-detail.jpg', badge: 'sale' as const, category: 'إكسسوارات', color: 'عنبر', sizes: ['موحد'] },
];

const categories = ['الكل', 'فساتين', 'تنانير', 'قمصان وبلوزات', 'معاطف وجاكيتات', 'إكسسوارات'];
const colors = ['أخضر', 'بيج', 'أسود', 'أبيض', 'عنبر', 'جملي'];
const sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

export default function Products() {
  const [activeCategory, setActiveCategory] = useState('الكل');
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState('الأحدث');
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const toggleColor = (color: string) => {
    setSelectedColors((prev) =>
      prev.includes(color) ? prev.filter((c) => c !== color) : [...prev, color]
    );
  };

  const toggleSize = (size: string) => {
    setSelectedSizes((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]
    );
  };

  let filtered = activeCategory === 'الكل'
    ? allProducts
    : allProducts.filter((p) => p.category === activeCategory);

  if (selectedColors.length > 0) {
    filtered = filtered.filter((p) => selectedColors.includes(p.color));
  }

  if (sortBy === 'السعر: من الأقل للأعلى') {
    filtered = [...filtered].sort((a, b) => a.price - b.price);
  } else if (sortBy === 'السعر: من الأعلى للأقل') {
    filtered = [...filtered].sort((a, b) => b.price - a.price);
  }

  const FilterContent = () => (
    <div className="space-y-8">
      {/* Categories */}
      <div>
        <h4 className="font-display text-lg font-semibold text-text-dark mb-4">الفئات</h4>
        <ul className="space-y-2">
          {categories.map((cat) => {
            const count = cat === 'الكل' ? allProducts.length : allProducts.filter((p) => p.category === cat).length;
            return (
              <li key={cat}>
                <button
                  onClick={() => setActiveCategory(cat)}
                  className={`font-body text-sm w-full text-right py-1.5 transition-colors ${
                    activeCategory === cat ? 'text-brand-gold font-medium' : 'text-text-muted hover:text-text-dark'
                  }`}
                >
                  {cat} ({count})
                </button>
              </li>
            );
          })}
        </ul>
      </div>

      {/* Colors */}
      <div>
        <h4 className="font-display text-lg font-semibold text-text-dark mb-4">اللون</h4>
        <div className="flex flex-wrap gap-2">
          {colors.map((color) => (
            <button
              key={color}
              onClick={() => toggleColor(color)}
              className={`w-8 h-8 rounded-full border-2 transition-all ${
                selectedColors.includes(color)
                  ? 'border-brand-gold scale-110'
                  : 'border-transparent hover:border-brand-gold/50'
              }`}
              style={{
                backgroundColor:
                  color === 'أخضر' ? '#2d5a4c' :
                  color === 'بيج' ? '#d4c4a8' :
                  color === 'أسود' ? '#1a1a1a' :
                  color === 'أبيض' ? '#f5f5f5' :
                  color === 'عنبر' ? '#c1915c' :
                  '#c4a882',
              }}
              title={color}
            />
          ))}
        </div>
      </div>

      {/* Sizes */}
      <div>
        <h4 className="font-display text-lg font-semibold text-text-dark mb-4">الحجم</h4>
        <div className="flex flex-wrap gap-2">
          {sizes.map((size) => (
            <button
              key={size}
              onClick={() => toggleSize(size)}
              className={`w-10 h-10 rounded-lg font-body text-xs font-medium border transition-all ${
                selectedSizes.includes(size)
                  ? 'bg-brand-gold text-white border-brand-gold'
                  : 'border-edge text-text-muted hover:border-brand-gold'
              }`}
            >
              {size}
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen pt-20">
      {/* Page Header */}
      <div className="bg-surface-light border-b border-edge py-10 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto">
          <h1 className="font-display text-4xl lg:text-5xl font-semibold text-text-dark mb-2">
            التشكيلة
          </h1>
          <p className="font-body text-text-muted">
            اكتشفي تشكيلتنا الواسعة من الأزياء النسائية المصممة بعناية فائقة
          </p>
        </div>
      </div>

      <div className="max-w-[1280px] mx-auto px-6 lg:px-20 py-10">
        {/* Sort & Filter Toggle */}
        <div className="flex items-center justify-between mb-8">
          <span className="font-body text-text-muted">{filtered.length} منتج</span>
          <div className="flex items-center gap-4">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="font-body text-sm bg-white border border-edge rounded-lg px-4 py-2 outline-none focus:border-brand-gold"
            >
              <option>الأحدث</option>
              <option>السعر: من الأقل للأعلى</option>
              <option>السعر: من الأعلى للأقل</option>
              <option>الأكثر مبيعاً</option>
            </select>
            <button
              onClick={() => setMobileFilterOpen(true)}
              className="lg:hidden flex items-center gap-2 font-body text-sm text-text-dark border border-edge px-4 py-2 rounded-lg"
            >
              <SlidersHorizontal size={16} />
              تصفية
            </button>
          </div>
        </div>

        <div className="flex gap-10">
          {/* Desktop Sidebar */}
          <aside className="hidden lg:block w-64 shrink-0">
            <FilterContent />
          </aside>

          {/* Product Grid */}
          <div className="flex-1">
            {filtered.length === 0 ? (
              <div className="text-center py-20">
                <p className="font-body text-text-muted text-lg">لا توجد منتجات مطابقة للتصفية</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-6">
                {filtered.map((product) => (
                  <ProductCard
                    key={product.id}
                    id={product.id}
                    name={product.name}
                    price={product.price}
                    originalPrice={product.originalPrice}
                    image={product.image}
                    badge={product.badge}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Filter Drawer */}
      {mobileFilterOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMobileFilterOpen(false)} />
          <div className="absolute top-0 right-0 bottom-0 w-80 bg-white p-6 overflow-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display text-xl font-semibold">تصفية</h3>
              <button onClick={() => setMobileFilterOpen(false)}>
                <X size={24} />
              </button>
            </div>
            <FilterContent />
          </div>
        </div>
      )}
    </div>
  );
}
