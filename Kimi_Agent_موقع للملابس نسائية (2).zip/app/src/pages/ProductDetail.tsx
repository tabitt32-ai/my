import { useState } from 'react';
import { useParams, Link } from 'react-router';
import { Heart, Minus, Plus, Check } from 'lucide-react';
import { useCartStore } from '@/store/cartStore';
import ProductCard from '@/components/ProductCard';

const productImages = [
  '/images/product-main.jpg',
  '/images/product-side.jpg',
  '/images/product-back.jpg',
  '/images/product-detail.jpg',
];

const colors = [
  { name: 'أخضر', value: '#2d5a4c' },
  { name: 'أسود', value: '#1a1a1a' },
  { name: 'عنبر', value: '#c1915c' },
];

const sizes = ['S', 'M', 'L', 'XL'];

const relatedProducts = [
  { id: '2', name: 'فستان عنبرية حريري', price: 699, image: '/images/category-tops.jpg' },
  { id: '3', name: 'فستان أسود كلاسيكي', price: 599, originalPrice: 799, image: '/images/category-coats.jpg', badge: 'sale' as const },
  { id: '12', name: 'وشاح حريري عنبر', price: 199, originalPrice: 249, image: '/images/product-detail.jpg', badge: 'sale' as const },
  { id: '10', name: 'معطف شتوي جملي', price: 599, image: '/images/category-coats.jpg' },
];

export default function ProductDetail() {
  const { id } = useParams();
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedColor, setSelectedColor] = useState(colors[0]);
  const [selectedSize, setSelectedSize] = useState('M');
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const addItem = useCartStore((s) => s.addItem);

  const handleAddToCart = () => {
    addItem({
      id: id || '1',
      name: 'فستان سهرة أخضر زمردي',
      price: 799,
      image: productImages[0],
      color: selectedColor.name,
      size: selectedSize,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="min-h-screen pt-20">
      {/* Breadcrumb */}
      <div className="bg-surface-light border-b border-edge py-4 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto">
          <div className="font-body text-sm text-text-muted">
            <Link to="/" className="hover:text-brand-gold transition-colors">الرئيسية</Link>
            <span className="mx-2">/</span>
            <Link to="/products" className="hover:text-brand-gold transition-colors">التشكيلة</Link>
            <span className="mx-2">/</span>
            <span className="text-text-dark">فستان سهرة أخضر زمردي</span>
          </div>
        </div>
      </div>

      <div className="max-w-[1280px] mx-auto px-6 lg:px-20 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Gallery */}
          <div className="flex gap-4">
            <div className="flex flex-col gap-3">
              {productImages.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedImage(i)}
                  className={`w-20 h-24 rounded-lg overflow-hidden border-2 transition-all ${
                    selectedImage === i ? 'border-brand-gold' : 'border-transparent hover:border-brand-gold/50'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
            <div className="flex-1 aspect-[3/4] rounded-xl overflow-hidden bg-surface-light">
              <img
                src={productImages[selectedImage]}
                alt="فستان سهرة أخضر زمردي"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Product Info */}
          <div>
            <h1 className="font-display text-3xl font-semibold text-text-dark mb-4">
              فستان سهرة أخضر زمردي
            </h1>

            <div className="flex items-center gap-4 mb-6">
              <span className="font-body font-bold text-2xl text-brand-gold">٧٩٩ ر.س</span>
              <span className="font-body text-lg text-text-muted line-through">٩٩٩ ر.س</span>
              <span className="bg-error text-white font-body text-xs font-medium px-3 py-1 rounded-full">
                خصم ٢٠٪
              </span>
            </div>

            <p className="font-body text-text-muted leading-relaxed mb-8">
              فستان سهرة فاخر بتصميم شرقي معاصر. قماش حريري ناعم بلون أخضر زمردي مذهل. يتميز بتطريز يدوي دقيق على الياقة والأكمام. قصة أنيقة تبرز جمال القوام مع تنورة طويلة تمنحكِ مظهراً ملكياً.
            </p>

            {/* Colors */}
            <div className="mb-6">
              <h4 className="font-body font-semibold text-text-dark mb-3">اللون: {selectedColor.name}</h4>
              <div className="flex gap-3">
                {colors.map((color) => (
                  <button
                    key={color.name}
                    onClick={() => setSelectedColor(color)}
                    className={`w-10 h-10 rounded-full border-2 transition-all ${
                      selectedColor.name === color.name ? 'border-brand-gold scale-110' : 'border-edge'
                    }`}
                    style={{ backgroundColor: color.value }}
                  />
                ))}
              </div>
            </div>

            {/* Sizes */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-body font-semibold text-text-dark">الحجم</h4>
                <button className="font-body text-sm text-brand-gold hover:underline">دليل المقاسات</button>
              </div>
              <div className="flex gap-2">
                {sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`w-12 h-12 rounded-lg font-body font-medium border transition-all ${
                      selectedSize === size
                        ? 'bg-brand-gold text-white border-brand-gold'
                        : 'border-edge text-text-dark hover:border-brand-gold'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div className="mb-8">
              <h4 className="font-body font-semibold text-text-dark mb-3">الكمية</h4>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 rounded-lg border border-edge flex items-center justify-center hover:border-brand-gold transition-colors"
                >
                  <Minus size={16} />
                </button>
                <span className="font-body font-semibold text-lg w-8 text-center">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 rounded-lg border border-edge flex items-center justify-center hover:border-brand-gold transition-colors"
                >
                  <Plus size={16} />
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={handleAddToCart}
                className={`flex-1 font-body font-medium py-4 rounded-lg shadow-button transition-all duration-300 flex items-center justify-center gap-2 ${
                  added
                    ? 'bg-success text-white'
                    : 'bg-gradient-gold text-white hover:shadow-button-hover hover:-translate-y-0.5'
                }`}
              >
                {added ? (
                  <>
                    <Check size={20} />
                    تم الإضافة
                  </>
                ) : (
                  'أضيفي إلى السلة'
                )}
              </button>
              <button className="w-14 h-14 rounded-lg border border-edge flex items-center justify-center hover:border-error hover:text-error transition-colors">
                <Heart size={20} />
              </button>
            </div>

            {/* Additional Info */}
            <div className="mt-8 pt-6 border-t border-edge space-y-2">
              <p className="font-body text-sm text-text-muted"><span className="text-text-dark font-medium">المادة:</span> حرير طبيعي ١٠٠٪</p>
              <p className="font-body text-sm text-text-muted"><span className="text-text-dark font-medium">التصنيع:</span> يدوي</p>
              <p className="font-body text-sm text-text-muted"><span className="text-text-dark font-medium">المقاس:</span> يأخذ المقاس الطبيعي</p>
              <p className="font-body text-sm text-text-muted"><span className="text-text-dark font-medium">العناية:</span> غسيل يدوي فقط</p>
            </div>
          </div>
        </div>
      </div>

      {/* Related Products */}
      <div className="bg-surface-light py-16 px-6 lg:px-20">
        <div className="max-w-[1280px] mx-auto">
          <h2 className="font-display text-2xl font-semibold text-text-dark mb-8">
            قد يعجبكِ أيضاً
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
