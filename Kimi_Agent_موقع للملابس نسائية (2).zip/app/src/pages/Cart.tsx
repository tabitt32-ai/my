import { Link } from 'react-router';
import { Trash2, Minus, Plus, ShoppingBag } from 'lucide-react';
import { useCartStore } from '@/store/cartStore';

export default function Cart() {
  const { items, removeItem, updateQuantity, getTotalPrice } = useCartStore();
  const total = getTotalPrice();

  if (items.length === 0) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center">
          <ShoppingBag size={80} className="text-edge mx-auto mb-6" />
          <h2 className="font-display text-2xl font-medium text-text-dark mb-3">
            سلة المشتريات فارغة
          </h2>
          <p className="font-body text-text-muted mb-8">
            ابدئي التسوق واكتشفي تشكيلتنا الرائعة من الأزياء النسائية
          </p>
          <Link
            to="/products"
            className="inline-block bg-gradient-gold text-white font-body font-medium px-10 py-4 rounded-lg shadow-button hover:shadow-button-hover hover:-translate-y-0.5 transition-all duration-300"
          >
            تصفحي المنتجات
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-20 py-10">
        <h1 className="font-display text-4xl font-semibold text-text-dark mb-2">
          سلة المشتريات
        </h1>
        <p className="font-body text-text-muted mb-8">
          {items.length} منتجات
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <div
                key={`${item.id}-${item.color}-${item.size}`}
                className="flex gap-4 bg-white rounded-xl p-4 shadow-card"
              >
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-28 h-36 object-cover rounded-lg"
                />
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-display text-base font-medium text-text-dark mb-1">
                      {item.name}
                    </h3>
                    <p className="font-body text-sm text-text-muted">
                      اللون: {item.color} | الحجم: {item.size}
                    </p>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-body font-bold text-brand-gold">
                      {item.price.toLocaleString('ar-SA')} ر.س
                    </span>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center border border-edge rounded-lg">
                        <button
                          onClick={() => updateQuantity(item.id, item.color, item.size, item.quantity - 1)}
                          className="w-8 h-8 flex items-center justify-center hover:text-brand-gold"
                        >
                          <Minus size={14} />
                        </button>
                        <span className="w-8 text-center font-body text-sm">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.color, item.size, item.quantity + 1)}
                          className="w-8 h-8 flex items-center justify-center hover:text-brand-gold"
                        >
                          <Plus size={14} />
                        </button>
                      </div>
                      <button
                        onClick={() => removeItem(item.id, item.color, item.size)}
                        className="text-text-muted hover:text-error transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Summary */}
          <div className="bg-white rounded-xl p-6 shadow-card h-fit">
            <h3 className="font-display text-xl font-semibold text-text-dark mb-6">
              ملخص الطلب
            </h3>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between font-body text-sm">
                <span className="text-text-muted">المجموع الفرعي</span>
                <span className="text-text-dark">{total.toLocaleString('ar-SA')} ر.س</span>
              </div>
              <div className="flex justify-between font-body text-sm">
                <span className="text-text-muted">الشحن</span>
                <span className="text-success font-medium">مجاني</span>
              </div>
              <div className="flex justify-between font-body text-sm">
                <span className="text-text-muted">الخصم</span>
                <span className="text-text-dark">-٠ ر.س</span>
              </div>
            </div>

            <div className="border-t border-edge pt-4 mb-6">
              <div className="flex justify-between font-body">
                <span className="font-semibold text-text-dark">الإجمالي</span>
                <span className="font-bold text-xl text-brand-gold">
                  {total.toLocaleString('ar-SA')} ر.س
                </span>
              </div>
            </div>

            <Link
              to="/checkout"
              className="block w-full text-center bg-gradient-gold text-white font-body font-medium py-4 rounded-lg shadow-button hover:shadow-button-hover hover:-translate-y-0.5 transition-all duration-300"
            >
              إتمام الطلب
            </Link>

            <Link
              to="/products"
              className="block w-full text-center font-body text-sm text-brand-gold mt-4 hover:underline"
            >
              مواصلة التسوق ←
            </Link>

            {/* Promo Code */}
            <div className="mt-6 pt-6 border-t border-edge">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="أدخلي كود الخصم"
                  className="flex-1 bg-surface-light border border-edge rounded-lg px-3 py-2 font-body text-sm outline-none focus:border-brand-gold"
                />
                <button className="font-body text-sm bg-surface-dark text-text-light px-4 py-2 rounded-lg hover:bg-surface-dark/90 transition-colors">
                  تطبيق
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
