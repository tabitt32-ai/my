import { useState } from 'react';
import { Link } from 'react-router';
import { Check, ChevronLeft, CreditCard, Smartphone, Wallet, Banknote } from 'lucide-react';
import { useCartStore } from '@/store/cartStore';

const steps = ['المعلومات', 'العنوان', 'الدفع', 'التأكيد'];

const cities = ['الرياض', 'جدة', 'مكة المكرمة', 'المدينة المنورة', 'الدمام', 'الخبر', 'تبوك', 'أبها'];

const paymentMethods = [
  { id: 'card', name: 'بطاقة ائتمانية', icon: CreditCard },
  { id: 'apple', name: 'أبل باي', icon: Smartphone },
  { id: 'mada', name: 'مدى', icon: Wallet },
  { id: 'cod', name: 'كاش عند الاستلام', icon: Banknote },
];

export default function Checkout() {
  const { items, getTotalPrice } = useCartStore();
  const [currentStep, setCurrentStep] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [orderPlaced, setOrderPlaced] = useState(false);

  const subtotal = getTotalPrice();
  const shipping = 0;
  const tax = Math.round(subtotal * 0.15);
  const total = subtotal + shipping + tax;

  const handlePlaceOrder = () => {
    setOrderPlaced(true);
    setCurrentStep(3);
  };

  if (orderPlaced) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center px-6">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-6">
            <Check size={40} className="text-success" />
          </div>
          <h2 className="font-display text-3xl font-semibold text-text-dark mb-4">
            تم تأكيد طلبكِ بنجاح!
          </h2>
          <p className="font-body text-text-muted mb-2">
            رقم الطلب: <span className="font-bold text-text-dark">#12345</span>
          </p>
          <p className="font-body text-text-muted mb-8">
            سنرسل لكِ تفاصيل الطلب عبر البريد الإلكتروني. يمكنكِ تتبع طلبكِ من خلال صفحة تتبع الطلبات.
          </p>
          <div className="flex gap-3 justify-center">
            <Link
              to="/track-order"
              className="bg-gradient-gold text-white font-body font-medium px-8 py-3 rounded-lg shadow-button"
            >
              تتبع الطلب
            </Link>
            <Link
              to="/products"
              className="border border-edge text-text-dark font-body font-medium px-8 py-3 rounded-lg hover:border-brand-gold"
            >
              مواصلة التسوق
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-20 py-10">
        <h1 className="font-display text-4xl font-semibold text-text-dark mb-8">إتمام الطلب</h1>

        {/* Progress */}
        <div className="flex items-center justify-center gap-4 mb-10">
          {steps.map((step, i) => (
            <div key={step} className="flex items-center gap-2">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center font-body text-xs font-medium ${
                  i < currentStep
                    ? 'bg-success text-white'
                    : i === currentStep
                    ? 'bg-brand-gold text-white'
                    : 'bg-edge text-text-muted'
                }`}
              >
                {i < currentStep ? <Check size={16} /> : i + 1}
              </div>
              <span
                className={`font-body text-sm hidden sm:block ${
                  i <= currentStep ? 'text-text-dark' : 'text-text-muted'
                }`}
              >
                {step}
              </span>
              {i < steps.length - 1 && (
                <ChevronLeft size={16} className="text-text-muted mr-2" />
              )}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
          {/* Form */}
          <div className="lg:col-span-3">
            {currentStep === 0 && (
              <div className="bg-white rounded-xl p-8 shadow-card">
                <h3 className="font-display text-xl font-semibold text-text-dark mb-6">
                  ١. المعلومات الشخصية
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="font-body text-sm text-text-dark mb-2 block">الاسم الأول *</label>
                    <input type="text" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                  </div>
                  <div>
                    <label className="font-body text-sm text-text-dark mb-2 block">الاسم الأخير *</label>
                    <input type="text" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                  </div>
                  <div className="col-span-2">
                    <label className="font-body text-sm text-text-dark mb-2 block">البريد الإلكتروني *</label>
                    <input type="email" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                  </div>
                  <div className="col-span-2">
                    <label className="font-body text-sm text-text-dark mb-2 block">رقم الهاتف *</label>
                    <input type="tel" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" placeholder="05xxxxxxxx" />
                  </div>
                </div>
              </div>
            )}

            {currentStep === 1 && (
              <div className="bg-white rounded-xl p-8 shadow-card">
                <h3 className="font-display text-xl font-semibold text-text-dark mb-6">
                  ٢. عنوان الشحن
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="font-body text-sm text-text-dark mb-2 block">المدينة *</label>
                    <select className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold bg-white">
                      <option>اختر المدينة</option>
                      {cities.map((city) => (
                        <option key={city}>{city}</option>
                      ))}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="font-body text-sm text-text-dark mb-2 block">الحي *</label>
                      <input type="text" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                    </div>
                    <div>
                      <label className="font-body text-sm text-text-dark mb-2 block">الشارع *</label>
                      <input type="text" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="font-body text-sm text-text-dark mb-2 block">رقم البناية/الفيلا *</label>
                      <input type="text" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                    </div>
                    <div>
                      <label className="font-body text-sm text-text-dark mb-2 block">الرقم الإضافي</label>
                      <input type="text" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                    </div>
                  </div>

                  <div className="mt-6 pt-6 border-t border-edge">
                    <h4 className="font-body font-semibold text-text-dark mb-4">خيارات التوصيل</h4>
                    <div className="space-y-3">
                      <label className="flex items-center justify-between p-4 border border-brand-gold rounded-lg bg-brand-gold/5 cursor-pointer">
                        <div className="flex items-center gap-3">
                          <input type="radio" name="shipping" defaultChecked className="accent-brand-gold" />
                          <span className="font-body text-sm">توصيل مجاني (3-5 أيام)</span>
                        </div>
                        <span className="font-body text-sm text-success font-medium">مجاني</span>
                      </label>
                      <label className="flex items-center justify-between p-4 border border-edge rounded-lg cursor-pointer">
                        <div className="flex items-center gap-3">
                          <input type="radio" name="shipping" className="accent-brand-gold" />
                          <span className="font-body text-sm">توصيل سريع (1-2 يوم)</span>
                        </div>
                        <span className="font-body text-sm text-text-dark font-medium">٤٩ ر.س</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="bg-white rounded-xl p-8 shadow-card">
                <h3 className="font-display text-xl font-semibold text-text-dark mb-6">
                  ٣. طريقة الدفع
                </h3>
                <div className="grid grid-cols-2 gap-3 mb-6">
                  {paymentMethods.map((method) => (
                    <button
                      key={method.id}
                      onClick={() => setPaymentMethod(method.id)}
                      className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                        paymentMethod === method.id
                          ? 'border-brand-gold bg-brand-gold/5'
                          : 'border-edge hover:border-brand-gold/50'
                      }`}
                    >
                      <method.icon size={24} className={paymentMethod === method.id ? 'text-brand-gold' : 'text-text-muted'} />
                      <span className="font-body text-xs">{method.name}</span>
                    </button>
                  ))}
                </div>

                {paymentMethod === 'card' && (
                  <div className="space-y-4">
                    <div>
                      <label className="font-body text-sm text-text-dark mb-2 block">رقم البطاقة</label>
                      <input type="text" placeholder="xxxx xxxx xxxx xxxx" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="font-body text-sm text-text-dark mb-2 block">تاريخ الانتهاء</label>
                        <input type="text" placeholder="MM/YY" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                      </div>
                      <div>
                        <label className="font-body text-sm text-text-dark mb-2 block">CVV</label>
                        <input type="text" placeholder="xxx" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                      </div>
                    </div>
                    <div>
                      <label className="font-body text-sm text-text-dark mb-2 block">اسم حامل البطاقة</label>
                      <input type="text" className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold" />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex gap-4 mt-6">
              {currentStep > 0 && (
                <button
                  onClick={() => setCurrentStep(currentStep - 1)}
                  className="font-body text-text-dark border border-edge px-8 py-3 rounded-lg hover:border-brand-gold transition-colors"
                >
                  السابق
                </button>
              )}
              {currentStep < 2 ? (
                <button
                  onClick={() => setCurrentStep(currentStep + 1)}
                  className="flex-1 bg-gradient-gold text-white font-body font-medium py-3 rounded-lg shadow-button hover:shadow-button-hover transition-all"
                >
                  التالي
                </button>
              ) : (
                <button
                  onClick={handlePlaceOrder}
                  className="flex-1 bg-gradient-gold text-white font-body font-medium py-3 rounded-lg shadow-button hover:shadow-button-hover transition-all"
                >
                  إتمام الطلب
                </button>
              )}
            </div>
          </div>

          {/* Summary */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl p-6 shadow-card sticky top-24">
              <h3 className="font-display text-lg font-semibold text-text-dark mb-4">
                ملخص الطلب
              </h3>
              <div className="space-y-3 mb-4 max-h-60 overflow-auto">
                {items.map((item) => (
                  <div key={`${item.id}-${item.color}-${item.size}`} className="flex gap-3">
                    <img src={item.image} alt={item.name} className="w-14 h-18 object-cover rounded-lg" />
                    <div className="flex-1">
                      <p className="font-body text-sm text-text-dark">{item.name}</p>
                      <p className="font-body text-xs text-text-muted">{item.color} / {item.size}</p>
                    </div>
                    <span className="font-body text-sm text-brand-gold">
                      {(item.price * item.quantity).toLocaleString('ar-SA')} ر.س
                    </span>
                  </div>
                ))}
              </div>
              <div className="border-t border-edge pt-4 space-y-2">
                <div className="flex justify-between font-body text-sm">
                  <span className="text-text-muted">المجموع الفرعي</span>
                  <span>{subtotal.toLocaleString('ar-SA')} ر.س</span>
                </div>
                <div className="flex justify-between font-body text-sm">
                  <span className="text-text-muted">الشحن</span>
                  <span className="text-success">مجاني</span>
                </div>
                <div className="flex justify-between font-body text-sm">
                  <span className="text-text-muted">الضريبة (١٥٪)</span>
                  <span>{tax.toLocaleString('ar-SA')} ر.س</span>
                </div>
                <div className="border-t border-edge pt-2 flex justify-between font-body">
                  <span className="font-semibold">الإجمالي</span>
                  <span className="font-bold text-xl text-brand-gold">{total.toLocaleString('ar-SA')} ر.س</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
