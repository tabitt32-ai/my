import { Mail, Phone, MapPin, Clock } from 'lucide-react';

export default function Contact() {
  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-20 py-16">
        <h1 className="font-display text-4xl font-semibold text-text-dark mb-12 text-center">
          تواصلي معنا
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-16">
          {/* Contact Info */}
          <div className="lg:col-span-2">
            <h3 className="font-display text-xl font-semibold text-text-dark mb-6">
              معلومات التواصل
            </h3>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-brand-gold/10 flex items-center justify-center shrink-0">
                  <Mail size={18} className="text-brand-gold" />
                </div>
                <div>
                  <p className="font-body text-sm text-text-muted mb-1">البريد الإلكتروني</p>
                  <p className="font-body text-text-dark">hello@layla-fashion.sa</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-brand-gold/10 flex items-center justify-center shrink-0">
                  <Phone size={18} className="text-brand-gold" />
                </div>
                <div>
                  <p className="font-body text-sm text-text-muted mb-1">الهاتف</p>
                  <p className="font-body text-text-dark">9200xxxxx</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-brand-gold/10 flex items-center justify-center shrink-0">
                  <MapPin size={18} className="text-brand-gold" />
                </div>
                <div>
                  <p className="font-body text-sm text-text-muted mb-1">الموقع</p>
                  <p className="font-body text-text-dark">الرياض، المملكة العربية السعودية</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-brand-gold/10 flex items-center justify-center shrink-0">
                  <Clock size={18} className="text-brand-gold" />
                </div>
                <div>
                  <p className="font-body text-sm text-text-muted mb-1">ساعات العمل</p>
                  <p className="font-body text-text-dark">السبت - الخميس: ٩ صباحاً - ٩ مساءً</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-xl p-8 shadow-card">
              <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="font-body text-sm text-text-dark mb-2 block">الاسم *</label>
                    <input
                      type="text"
                      className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/15 transition-all"
                    />
                  </div>
                  <div>
                    <label className="font-body text-sm text-text-dark mb-2 block">البريد الإلكتروني *</label>
                    <input
                      type="email"
                      className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/15 transition-all"
                    />
                  </div>
                </div>
                <div>
                  <label className="font-body text-sm text-text-dark mb-2 block">الموضوع *</label>
                  <select className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/15 transition-all bg-white">
                    <option>استفسار عام</option>
                    <option>طلب خاص</option>
                    <option>شكوى</option>
                    <option>اقتراح</option>
                  </select>
                </div>
                <div>
                  <label className="font-body text-sm text-text-dark mb-2 block">الرسالة *</label>
                  <textarea
                    rows={5}
                    className="w-full border border-edge rounded-lg px-4 py-3 font-body outline-none focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/15 transition-all resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-gradient-gold text-white font-body font-medium py-4 rounded-lg shadow-button hover:shadow-button-hover hover:-translate-y-0.5 transition-all duration-300"
                >
                  إرسال الرسالة
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Map Placeholder */}
      <div className="h-64 lg:h-80 bg-surface-cream flex items-center justify-center">
        <div className="text-center">
          <MapPin size={32} className="text-brand-gold mx-auto mb-3" />
          <p className="font-body text-text-muted">الرياض، المملكة العربية السعودية</p>
        </div>
      </div>
    </div>
  );
}
